<template>
  <div id="app">
    <div class="hero is-white is-gradient is-bold">
      <div class="hero-body">
        <h1 class="title">
          <span class="has-text-success">Rick&Morti</span>
          <span class="subtitle">personajes</span>
          
        </h1>
        <button v-on:click="fetch" class="button is-success is-rounded">consultar</button>
      </div>
    </div>
<!-- ##########################################################3-->

    <div class="container">
      <div class="columns is-desktop is-mobile is-tablet is-multiline is-centered">
        <character v-for="character of characters" v-bind:key="character.id" v-bind:character="character"/>
      </div>
    </div>
    
    
  
  </div>
</template>

<script>

import axios from 'axios';
import Character from './components/Character';

export default {
  name: "App",
  components:{
    Character //character
  },
  data: function(){
    return{
      characters:[]
    }
  },

created (){
  this.fetch();
}
  ,
  methods:{
    fetch(){   //ir a buscar
      let result = axios.get("https://rickandmortyapi.com/api/character") // let variable local 
      .then((res)=> {   //res respuesta y resive una funcion 
      this.characters = res.data.results;
     console.log(res.data); //paquete de datos en la libreria de axios  
      })

      .catch(err =>  { //cachar el error
        console.log(err); //imprimir el error
      })

    }
  }
};
</script>

